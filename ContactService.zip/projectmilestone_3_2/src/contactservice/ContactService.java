package contactservice;

import java.util.ArrayList;
import java.util.List;

public class ContactService {
	private List<Contact> contacts = new ArrayList<>();
	
	public void addContact(Contact contact) {
	    if (contact == null) {
	        throw new IllegalArgumentException("Contact cannot be null.");
	    }

	    if (getContact(contact.getContactId()) != null) {
	        throw new IllegalArgumentException("Contact ID already exists.");
	    }

	    contacts.add(contact);
	}
	public Contact getContact(String contactId) {
	    for (Contact contact : contacts) {
	        if (contact.getContactId().equals(contactId)) {
	            return contact;
	        }
	    }

	    return null;
	}
	public void deleteContact(String contactId) {
	    Contact contact = getContact(contactId);

	    if (contact == null) {
	        throw new IllegalArgumentException("Contact not found.");
	    }

	    contacts.remove(contact);
	}
	public void updateFirstName(String contactId, String firstName) {
	    Contact contact = getContact(contactId);

	    if (contact == null) {
	        throw new IllegalArgumentException("Contact not found.");
	    }

	    contact.setFirstName(firstName);
	}

	public void updateLastName(String contactId, String lastName) {
	    Contact contact = getContact(contactId);

	    if (contact == null) {
	        throw new IllegalArgumentException("Contact not found.");
	    }

	    contact.setLastName(lastName);
	}

	public void updatePhone(String contactId, String phone) {
	    Contact contact = getContact(contactId);

	    if (contact == null) {
	        throw new IllegalArgumentException("Contact not found.");
	    }

	    contact.setPhone(phone);
	}

	public void updateAddress(String contactId, String address) {
	    Contact contact = getContact(contactId);

	    if (contact == null) {
	        throw new IllegalArgumentException("Contact not found.");
	    }

	    contact.setAddress(address);
	}
}
